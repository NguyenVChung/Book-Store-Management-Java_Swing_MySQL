CREATE TABLE `book`.`user` (
Id char(10),
userName char(50),
pass char(50),
PRIMARY KEY(Id)
);