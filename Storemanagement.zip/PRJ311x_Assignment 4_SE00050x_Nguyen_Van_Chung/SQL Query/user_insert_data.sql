INSERT INTO book.store VALUES('B01','Tu Tien Thuat','NVC',2017,'Dung thanh phim thi tuyet');
INSERT INTO book.store VALUES('B02','Bo Gia','NVC',1954,'Phim cung rat tuyet nhe');
INSERT INTO book.store VALUES('B03','De Men Phieu Luu Ki','To Hoai',1943,'Cau chuyen gan lien voi tuoi tho cua nhieu the he');