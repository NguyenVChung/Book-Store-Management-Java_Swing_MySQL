CREATE TABLE `book`.`store` (
BCode char(20),
BName varchar(20),
Author varchar(10),
PYear int,
Preface varchar(255),
PRIMARY KEY(BCode)
);
