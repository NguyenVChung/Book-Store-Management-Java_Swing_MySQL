INSERT INTO book.user VALUES('U1','chung','1234');
INSERT INTO book.user VALUES('U2','admin','2345');